package logic;

public class InvalidIngredientException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -73944227945415371L;
	
	public InvalidIngredientException(String str) {
		super(str);
	}

}

package logic;

public class StringUtil {
	public static String formatNamePercentage(String name, int percentage) {
		return name+" ("+percentage+"%)";
	}
}
